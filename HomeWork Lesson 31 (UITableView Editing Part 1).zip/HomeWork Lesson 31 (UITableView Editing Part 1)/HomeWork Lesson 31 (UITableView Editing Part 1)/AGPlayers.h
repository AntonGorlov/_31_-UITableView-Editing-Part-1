//
//  AGPlayers.h
//  HomeWork Lesson 31 (UITableView Editing Part 1)
//
//  Created by Anton Gorlov on 01.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGPlayers : NSObject

@property(strong,nonatomic) NSString* firstLastName;
@property(assign,nonatomic) float     countGols;

+ (AGPlayers*) randomPlayers;

@end
