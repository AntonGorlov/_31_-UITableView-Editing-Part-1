//
//  AGPlayers.m
//  HomeWork Lesson 31 (UITableView Editing Part 1)
//
//  Created by Anton Gorlov on 01.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGPlayers.h"

@implementation AGPlayers

static NSString* firstName [] = {
    
    @"1. David De Gea (GK)",
    @"4. Phil Jones",
    @"12. Chris Smalling",
    @"17. Daley Blind",
    @"25. Antonio Valencia",
    @"8. Juan Mata",
    @"18. Ashley Young",
    @"21. Ander Herrera",
    @"31. Bastian Schweinsteiger",
    @"9. Anthony Martial",
    @"10. Wayne Rooney",
    @"11. Adnan Januzaj",
    @"5. Marcos Rojo",
    @"7. Memphis",
    @"16. Michael Carrick",
    @"23. Luke Shaw",
    @"27. Marouane Fellaini",
    @"28. Morgan Schneiderlin",
    @"35. Jesse Lingard",
    @"36. Matteo Darmian",
    @"39. Marcus Rashford",
    @"52. Ro-Shaun Williams",
    @"51. Timothy Fosu-Mensah",
    @"50. Sam Johnstone",
    @"49. Joe Riley",
    @"48. Will Keane",
    @"47. James Weir",
    @"11. Robin Van Perse",
    @"44. Andreas Pereira",
    @"42. Tyler Blackett",
    @"43. Cameron Borthwick-Jackson",
    @"46. Joe Rothwell",
    @"45. Sean Goss",
    @"41. Regan Poole",
    @"38. Axel Tuanzebe",
    @"37. Donald Love",
    @"33. Paddy McNair",
    @"30. Guillermo Varela",
    @"20. Sergio Romero (GK)",
    @"19. James Wilson",
    
    
};


static int nameCount = 40;

+ (AGPlayers*) randomPlayers {
    
    AGPlayers* players = [[AGPlayers alloc]init];
    players.firstLastName = firstName [arc4random() % nameCount];
    players.countGols = arc4random() % 27+5.f;// от 5 до 31
    
    
    return players;
}

@end
