//
//  ViewController.h
//  HomeWork Lesson 31 (UITableView Editing Part 1)
//
//  Created by Anton Gorlov on 01.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (strong, nonatomic) NSMutableArray *groupArray;
@property (strong, nonatomic) NSArray* teamsName; //название групп (секций)
@end

