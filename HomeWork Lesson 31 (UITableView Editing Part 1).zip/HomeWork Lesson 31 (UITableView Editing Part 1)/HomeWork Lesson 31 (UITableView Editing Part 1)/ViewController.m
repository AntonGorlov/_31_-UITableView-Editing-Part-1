//
//  ViewController.m
//  HomeWork Lesson 31 (UITableView Editing Part 1)
//
//  Created by Anton Gorlov on 01.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"
#import "AGGroup.h"
#import "AGPlayers.h"

@interface ViewController ()

@end

/*
 
 
 Урок номер 31 - 32. UITableView Editing.
 Итак редактируем наши таблицы.
 
 Задание.
 
 Ученик (в новом XCODE нельзя создавать пустое приложение!!!)
 
 1. Создайте контроллер с таблицей в коде без сторибордов.
 2. Заполните таблицу данными на свое усмотрение
 3. Объедините данные в группы (секции)
 
 Студент.
 
 4. Реализуйте механизм перемещения данных между рядами и секциями
 5. Вы должны четко понимать что и как работает и в какой последовательности поэтому повторяйте задание пока вы полностью не освоите этот механизм
*/
@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [self statusBarInsets];
    
    self.view.backgroundColor = [UIColor blueColor];
    
    [self addTitle]; //название секций
    
    self.groupArray = [NSMutableArray array];
    
    for (int i = 0; i < (arc4random() % 6 + 4.f); i++) { //количество групп (секций)от 4 до 8
        
        AGGroup* group = [[AGGroup alloc ]init];
        //group.name = [NSString stringWithFormat:@"Team %d",i];
        NSMutableArray* array = [NSMutableArray array];
        
        
        for (int j = 0; j < 5; j++) {//  по 5 человек в группе
            [array addObject:[AGPlayers randomPlayers ]];
        }
        group.players = array;
        [self.groupArray addObject:group];
    }
    
    [self.tableView reloadData]; //чтобы перезагрузить дату нашей tableView
    self.tableView.editing = YES; //разрешить редактирование
}



// Уровень "Студент"

#pragma mark- UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return [self.groupArray count];
    
}

- (nullable NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    //return [[self.groupArray objectAtIndex:section]name];
    
    NSString* titleForHeaderInSection = [NSString stringWithFormat:@"%@",[self.teamsName objectAtIndex:section]];
    
    return titleForHeaderInSection;
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    AGGroup* group = [self.groupArray objectAtIndex:section];
    
    return [group.players count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString* identifier = @"cell";
    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    
    if (!cell) {
        
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        cell.textLabel.textColor = [UIColor redColor];
    }
    
    AGGroup* group = [self.groupArray objectAtIndex:indexPath.section];
    AGPlayers* players = [group.players objectAtIndex:indexPath.row];
    
    cell.textLabel.text = [NSString stringWithFormat:@"%@",players.firstLastName];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%1.f",players.countGols];
    
    if (players.countGols >= 28) {
        cell.detailTextLabel.textColor = [UIColor greenColor];
        cell.textLabel.textColor = [UIColor greenColor];
    }
    
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return YES;
}


- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath {
    
    AGGroup* sourceGroup = [self.groupArray objectAtIndex:sourceIndexPath.section];
    AGPlayers* players = [sourceGroup.players objectAtIndex:sourceIndexPath.row];
    
    NSMutableArray* tempArray = [NSMutableArray arrayWithArray:sourceGroup.players];
    
    if (sourceIndexPath.section == destinationIndexPath.section) {
        
        [tempArray exchangeObjectAtIndex:sourceIndexPath.row withObjectAtIndex:destinationIndexPath.row];
        sourceGroup.players = tempArray;
        
    }else {
        
        [tempArray removeObject:players];
        sourceGroup.players = tempArray;
        
        AGGroup* destinationGroup = [self.groupArray objectAtIndex:destinationIndexPath.section];
        
        tempArray = [NSMutableArray arrayWithArray:destinationGroup.players];
        [tempArray insertObject:players atIndex:destinationIndexPath.row];
        destinationGroup.players = tempArray;
        
    }
}


#pragma mark- UITableViewDelegate

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return UITableViewCellEditingStyleNone;
    
}

#pragma mark- Methods

- (void) statusBarInsets {
    
    UIEdgeInsets topInsets = UIEdgeInsetsMake(20, 0, 0, 0);
    self.tableView.scrollIndicatorInsets = topInsets;
    self.tableView.contentInset = topInsets;
    
    UIEdgeInsets rightInsets = UIEdgeInsetsMake(0, 0, 0, 20);
    self.tableView.separatorInset = rightInsets;
}

- (void) addTitle {

    self.teamsName = [NSArray arrayWithObjects:   @"Team 1",
                                                  @"Team 2",
                                                  @"Team 3",
                                                  @"Team 4",
                                                  @"Team 5",
                                                  @"Team 6",
                                                  @"Team 7",
                                                  @"Team 8",
                                                  @"Team 9",
                                                  @"Team 10",nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
