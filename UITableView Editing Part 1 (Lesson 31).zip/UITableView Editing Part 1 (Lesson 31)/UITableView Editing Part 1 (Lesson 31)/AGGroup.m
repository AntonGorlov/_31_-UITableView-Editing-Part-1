//
//  AGGroup.m
//  UITableView Editing Part 1 (Lesson 31)
//
//  Created by Anton Gorlov on 28.03.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGGroup.h"

@implementation AGGroup

@end
