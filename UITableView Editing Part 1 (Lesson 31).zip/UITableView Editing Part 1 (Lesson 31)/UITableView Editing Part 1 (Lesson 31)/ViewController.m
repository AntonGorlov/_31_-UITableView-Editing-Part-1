//
//  ViewController.m
//  UITableView Editing Part 1 (Lesson 31)
//
//  Created by Anton Gorlov on 28.03.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"
#import "AGGroup.h"
#import "AGStudent.h"

@interface ViewController () <UITableViewDelegate , UITableViewDataSource>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self statusBarInsets];// отступы
    self.tableView.backgroundColor = [UIColor lightGrayColor];
   
    self.tableView.editing = YES; // возможность перетаскивать строки (режим редактирования)
    
    self.groupArray = [NSMutableArray array];
    
    
    for (int i = 0; i < (arc4random() % 6 + 5.f); i++) { //соз количество групп (секций)
        
        AGGroup* group = [[AGGroup alloc]init];
        group.name = [NSString stringWithFormat:@"group %d",i];
        
        NSMutableArray* array = [NSMutableArray array];
        
        
        for (int j = 0; j < (arc4random() % 11 +5.f ); j++) { //кол-во студентов в группе (рядов)
            [array addObject:[AGStudent randomStudent]];
        }
        
        group.students = array;
        
        [self.groupArray addObject:group]; // добавим в массив группы
    }
    
    [self.tableView reloadData]; //чтобы перезагрузить дату нашей tableView делаем reloadData
    
}

#pragma mark- UITableViewDataSource



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return [self.groupArray count]; //количество секций -это кол-во групп
}

- (nullable NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    return [[self.groupArray objectAtIndex:section] name];//выводим имя группы

}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    AGGroup* group = [self.groupArray objectAtIndex:section];

    return [group.students count]; //выводим количество студентов

}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString* identifier = @"cell";
    
    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    }
    //заполняем нашу ячейку
    
    AGGroup* group = [self.groupArray objectAtIndex:indexPath.section];
    AGStudent* student = [group.students objectAtIndex:indexPath.row];
    
    cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", student.firstName, student.lastName];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%1.0f", student.averageScore];
    
    
    if (student.averageScore == 5) {
        cell.detailTextLabel.textColor = [UIColor greenColor];
    }else if (student.averageScore == 4) {
        
         cell.detailTextLabel.textColor = [UIColor orangeColor];
        
    }else if (student.averageScore == 3) {
    
    
     cell.detailTextLabel.textColor = [UIColor cyanColor];
    
    }else {
    
     cell.detailTextLabel.textColor = [UIColor redColor];
    }
        



    return cell;
}


#pragma mark- moveCell
//перетягивание ячеек

- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {// метод,который вкл/выкл перенос по этому indexPath для такой section по такому row
    
    /*
    AGGroup* sourceGroup = [self.groupArray objectAtIndex:indexPath.section];
    AGStudent* student = [sourceGroup.students objectAtIndex:indexPath.row];
   
    return student.averageScore < 4.f; //если меньше 4,то можно перетягивать
   */
    return YES;

}

- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath {

//sourceIndexPath - источник (откуда?)
//destinationIndexPath - местоназначение (куда?-где?)

    
    AGGroup* sourceGroup = [self.groupArray objectAtIndex:sourceIndexPath.section]; // из какой группы переносим студентов
    AGStudent* student = [sourceGroup.students objectAtIndex:sourceIndexPath.row]; // какого студента (найдем нашего студента)
    
    NSMutableArray* tempArray = [NSMutableArray arrayWithArray:sourceGroup.students]; // соз новый NSMutableArray на основе arrayстудентов
    
    if (sourceIndexPath.section == destinationIndexPath.section) {//если секция source такая же как и destination (если перенос в пределаъ группы)
        [tempArray exchangeObjectAtIndex:sourceIndexPath.row withObjectAtIndex:destinationIndexPath.row]; //метод,который внутри одной секции массива меняет по индексам
        sourceGroup.students = tempArray;
        
    }else {      //если не в пределах одной группы (section)
    
        [tempArray removeObject:student]; // удалим студента
        sourceGroup.students = tempArray;
        
        AGGroup* destinationGroup = [self.groupArray objectAtIndex:destinationIndexPath.section]; // переносим студента в новую группу
        tempArray = [NSMutableArray arrayWithArray:destinationGroup.students];
        [tempArray insertObject:student atIndex:destinationIndexPath.row];// добавляем студента по индексу
        destinationGroup.students = tempArray;

    
    }
}


#pragma mark- UITableViewDelegate

//метод,который добавляет/убирает значки редактирования (красный кружок) и (зеленый кружок)

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {


    return UITableViewCellEditingStyleNone; //значки отсутствуют
}

#pragma mark- Methods

- (void) statusBarInsets {

    UIEdgeInsets topInsets = UIEdgeInsetsMake(20, 0, 0, 0);
    self.tableView.contentInset = topInsets;
    self.tableView.scrollIndicatorInsets = topInsets;
    
     UIEdgeInsets rightInsets = UIEdgeInsetsMake(0, 0, 0, 20);
    self.tableView.separatorInset = rightInsets;
    }








- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
