//
//  main.m
//  UITableView Editing Part 1 (Lesson 31)
//
//  Created by Anton Gorlov on 28.03.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
